import cv2
import numpy as np
import math


def solution(image_path):
    ############################
    ############################

    ############################
    ############################
    ## comment the line below before submitting else your code wont be executed##
    # pass
    image = cv2.imread(image_path)
    # return image
    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply edge detection to find lines in the image
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)

    # Find lines in the edge-detected image using Hough Transform
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100, minLineLength=100, maxLineGap=10)

    # Calculate the angle of the most prominent line detected (median of all lines)
    if lines is not None:
        angles = [np.arctan2(y2 - y1, x2 - x1) for line in lines for x1, y1, x2, y2 in line]
        predominant_angle = np.median(angles)
    else:
        predominant_angle = 0

    # Rotate the image to the required angle
    angle = predominant_angle * (180 / math.pi)  # Angle in degrees
    if angle < 0:
        angle += 180

    height, width = image.shape[:2]
    center = (width // 2, height // 2)

    # Rotate the original image and overlay it onto the white background
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, scale=0.9)
    rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height), borderMode=cv2.BORDER_CONSTANT,
                                   borderValue=(255, 255, 255))

    return rotated_image
