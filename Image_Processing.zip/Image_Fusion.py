import cv2
import numpy as np

def solution(image_path_a, image_path_b):
    img_a = cv2.imread(image_path_a).astype(np.float64)
    img_b = cv2.imread(image_path_b).astype(np.float64)

    fused_img = cv2.addWeighted(img_a, 0.8, img_b, 0.2, 0)

    def custom_bilateral_filter(input_img, diameter, sigma_color, sigma_space):
        d = diameter // 2
        height, width, _ = input_img.shape

        x, y = np.meshgrid(np.arange(-d, d + 1), np.arange(-d, d + 1))
        spatial_filter = np.exp(-(x**2 + y**2) / (2 * sigma_space**2))

        output_img = np.zeros_like(input_img)

        for i in range(height):
            for j in range(width):
                pixel = input_img[i, j]

                start_i, end_i = max(0, i - d), min(height, i + d + 1)
                start_j, end_j = max(0, j - d), min(width, j + d + 1)

                color_filter = np.exp(-np.sum((pixel - input_img[start_i:end_i, start_j:end_j])**2, axis=-1) / (2 * sigma_color**2))
                combined_filter = color_filter * spatial_filter[:end_i - start_i, :end_j - start_j]
                combined_filter /= np.sum(combined_filter)

                output_img[i, j] = np.sum((input_img[start_i:end_i, start_j:end_j].T * combined_filter).T, axis=(0, 1))

        return output_img.astype(np.uint8)

    diameter = 1
    sigma_color = 75
    sigma_space = 75

    bilateral_filtered_img = custom_bilateral_filter(fused_img, diameter, sigma_color, sigma_space)

    return bilateral_filtered_img

