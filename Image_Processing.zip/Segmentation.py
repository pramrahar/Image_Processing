import cv2
import numpy as np

def apply_mean_shift_and_mask(image, spatial_radius, color_radius, lower_color, upper_color, gaussian_kernel_size):
    lab_image = cv2.cvtColor(image, cv2.COLOR_BGR2Lab)
    mean_shifted = cv2.pyrMeanShiftFiltering(lab_image, sp=spatial_radius, sr=color_radius)
    segmented_mask = np.zeros_like(mean_shifted[:, :, 0], dtype=np.uint8)
    segmented_mask[mean_shifted[:, :, 0] > 0] = 255
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    color_mask = cv2.inRange(hsv, lower_color, upper_color)
    final_mask = cv2.bitwise_and(segmented_mask, color_mask)
    final_mask = cv2.GaussianBlur(final_mask, (gaussian_kernel_size, gaussian_kernel_size), 0)
    return final_mask

def apply_denoising(image, strength):
    return cv2.fastNlMeansDenoisingColored(image, None, h=strength, hColor=strength, templateWindowSize=7, searchWindowSize=21)

def remove_small_objects(mask, min_size):
    kernel = np.ones((5, 5), np.uint8)
    closing = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    opening = cv2.morphologyEx(closing, cv2.MORPH_OPEN, kernel, iterations=2)
    contours, _ = cv2.findContours(opening, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        area = cv2.contourArea(contour)
        if area < min_size:
            cv2.drawContours(opening, [contour], 0, 0, -1)
    return opening

def apply_thresholding(image, threshold_value):
    _, thresholded = cv2.threshold(image, threshold_value, 255, cv2.THRESH_BINARY)
    return thresholded

def solution(image_path):
    img = cv2.imread(image_path)
    lower_lava_hsv = np.array([0, 120, 135])
    upper_lava_hsv = np.array([50, 252, 255])
    spatial_radius = 10
    color_radius = 20
    gaussian_kernel_size = 5
    denoising_strength = 10
    min_object_size = 500
    threshold_value = 100

    mean_shift_and_mask = apply_mean_shift_and_mask(img, spatial_radius, color_radius, lower_lava_hsv, upper_lava_hsv, gaussian_kernel_size)
    result = cv2.bitwise_and(img, img, mask=mean_shift_and_mask)
    denoised_result = apply_denoising(result, denoising_strength)
    final_mask = remove_small_objects(mean_shift_and_mask, min_object_size)
    thresholded_result = apply_thresholding(denoised_result, threshold_value)
    final_result = cv2.bitwise_and(thresholded_result, thresholded_result, mask=final_mask)

    return final_result
